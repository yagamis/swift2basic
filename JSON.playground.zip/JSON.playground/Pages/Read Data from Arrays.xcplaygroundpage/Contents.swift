/*:
****
# 从数组中读数据

当JSON中包含一个同类型元素的数组时, 你可以给这个元素的类型加上 `Codable` 协议.
再解析整个数组的话, 用 `[Element].self` 语法.

下例中的  `WeatherNow` 可以被自动解析，因为定义时遵从了 `Codable` 协议。
使用 `decode` 方法能把JSON中的整个数组解析出来.

*/

import Foundation

let json = """
[
    {
        "name": "武汉",
        "temperature": "39",
        "text": "晴"
    },
    {
        "name": "上海",
        "temperature": "38",
        "text": "阴"
    },
    {
        "name": "北京",
        "code": "4",
        "temperature": "22",
        "text": "多云"
    }
]
""".data(using: .utf8)!

struct WeatherNow: Codable {
    var name: String
    var temperature: String
    var text: String
}

let decoder = JSONDecoder()
let citiesWeather = try decoder.decode([WeatherNow].self, from: json)

//print("城市天气实况:")
//for cityWeather in citiesWeather {
//    print("\t\(cityWeather.name) \(cityWeather.temperature)度 \(cityWeather.text)")
//}



/*:
如果上面的JSON数组其中哪怕有一个不是 `WeatherNow` 的实例，解析就失败(多余的属性不解析没有问题)。
如此严格的键和属性对应，会避免低级的拼写错误。（给定属性名，就可以自动生成代码😁）
*/
let url = URL(string: "http://www.toutiao.com/c/user/article/?page_type=1&user_id=3400026401&max_behot_time=0&count=20&as=A1B5382B95E4C02&cp=58B5747C80723E1")!

struct News : Decodable {
    let abstract: String
    let chinese_tag: String
    let source: String
    let go_detail_count: Int
    let single_mode: Bool
}

struct NewsService : Decodable {
    let message: String
    let data: [News]
}

do {
    let data = try Data(contentsOf: url)
    print("取新闻数据成功！")
    
    let newsService = try JSONDecoder().decode(NewsService.self, from: data)
    print("成功解析新闻数据")
    
    let news = newsService.data
    
    for new in news {
    print(new.abstract,new.chinese_tag,new.go_detail_count,new.source)
    }
    
} catch  {
    print(error)
}

